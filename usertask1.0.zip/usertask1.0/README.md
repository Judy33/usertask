1,step2 delete图片文字不对齐

time-line样式不对 border不在对的位置

step2 缩放样式不对

4月29日
正在做step2限制规则