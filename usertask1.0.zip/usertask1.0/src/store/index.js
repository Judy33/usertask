import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    stepOne:{}
  },
  mutations: {
    getStepOneData(state,payload){
      // payload.map(item =>{
      //   console.log(item)
      // })
      // console.log(state)
        this.state.stepOne = payload
        console.log( '-----11')
        console.log( this.state.stepOne)
    },
    getStepTwoData(state,payload){
      // payload.map(item =>{
      //   console.log(item)
      // })
      // console.log(state)
        // this.state.stepOne = payload
        console.log( '-----22')
        console.log(payload)
        // console.log( this.state.stepOne)
    }
  },
  actions: {
  },
  modules: {
  }
})
