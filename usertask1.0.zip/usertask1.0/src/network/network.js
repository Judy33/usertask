import request from "./request"

export  function submitTaskForm (){
  request({
      url: '',
      params: {}
  })
}