import Axios from 'axios'

export default function request(config){
     const instance1 = Axios.create({
        baseURL: ""
    })
    return instance1(config)
}