function getObjectUrl(file) {
    // this.
    let url = null;
    if (window.createObjectURL != undefined) {
      // basic
      url = window.createObjectURL(file);
    } else if (window.webkitURL != undefined) {
      // webkit or chrome
      url = window.webkitURL.createObjectURL(file);
    } else if (window.URL != undefined) {
      // mozilla(firefox)
      url = window.URL.createObjectURL(file);
    }
    this.userImgUrl = url;
  }

  //点击上传文件 获取文件
  function handleClickUpload(e) {
    this.file = e.target.files[0];
    if (!this.fristFile) {
      //没有上传过文件 就获取e.target
      this.fristFile = this.file;
      this.getObjectUrl(this.fristFile);
      this.ensureUpload = false;
    } else {
      //没有取消选择图片
      if (e.target.files.length > 0) {
        this.getObjectUrl(e.target.files[0]);
      }
    }
    //获取图片地址
    // console.log("已经得到图片");
    // this.toAli(file)
  }

  //上传图片的加载层
  function uploadImg() {
    this.$Spin.show({
      render: h => {
        return h("div", [
          h("Icon", {
            class: "demo-spin-icon-load",
            props: {
              type: "ios-loading",
              size: 18
            }
          }),
          h("div", "上传图片中")
        ]);
      }
    });
  }
  export { getObjectUrl,handleClickUpload, uploadImg}