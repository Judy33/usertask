<template>
  <div id="step-three">
    <tab-bar :title="title" />
    <div class="content">
      <time-line :step="3" />
      <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" label-position="top">
        <FormItem label="奖励类型：" prop="awardType">
          <!-- prop是指向类型检测 -->
          <Select v-model="formValidate.awardType" placeholder="请选择">
            <!-- v-model显示默认值要绑定value -->
            <Option value="USDT">USDT</Option>
            <Option value="APT">APT</Option>
          </Select>
        </FormItem>

        <FormItem label="用户得到的奖励金额(单个任务)" prop="money" labelFor="Name">
          <Input v-model="formValidate.money" placeholder="请填写用户得到的奖励金额" elementId="Name" />
        </FormItem>

        <FormItem label="总任务数" prop="taskCount">
          <Input v-model="formValidate.taskCount" placeholder="请填写总任务数 最少10个" />
        </FormItem>

        <FormItem label="任务时间(例如30分钟，就填写30)" prop="requiredTime">
          <Input v-model="formValidate.requiredTime" placeholder="用户完成任务所需时间" />

          <!-- <Row> -->
          <!-- <Col span="11">
              <FormItem prop="date">
                <DatePicker type="date" placeholder="Select date" v-model="formValidate.date"></DatePicker>
              </FormItem>
          </Col>-->
          <!-- <Col span="2" style="text-align: center">-</Col> -->
          <!-- <Col span="11">
          <FormItem prop="time">
            <TimePicker type="time" placeholder="Select time" v-model="formValidate.time"></TimePicker>
          </FormItem>
          </Col>-->
          <!-- </Row> -->
        </FormItem>
        <FormItem label="任务下架时间(零点下架)">
          <!-- <Row> -->
          <!-- <Col span="11"> -->
          <FormItem prop="deadline">
            <DatePicker type="date" placeholder="请选择(时间到任务自动下架)" v-model="formValidate.deadline"></DatePicker>
          </FormItem>
          <!-- </Col>
          </Row>-->
        </FormItem>
        <div class="money-count">
          <div class="money">
            <p class="left">任务奖励总金额：</p>
            <p class="right">
              <!-- 用户奖励*任务总数 -->
              {{formValidate.money * formValidate.taskCount}}
              {{formValidate.awardType}}
            </p>
          </div>
          <div class="charge">
            <p class="left">任务上架手续费：</p>
            <p class="right">
              <!-- 用户奖励*任务总数*20%  -->
              {{formValidate.money * formValidate.taskCount *0.02}}
              {{formValidate.awardType}}
            </p>
          </div>
          <div class="pay">
            <p class="left">需要支付</p>
            <p class="right">
              <!-- 任务奖励金额+任务上架手续费  -->
              {{formValidate.money * formValidate.taskCount + formValidate.money * formValidate.taskCount *0.02}}
              {{formValidate.awardType}}
            </p>
          </div>
        </div>
        <!-- <FormItem label="Desc" prop="desc">
      <Input
        v-model="formValidate.desc"
        type="textarea"
        :autosize="{minRows: 2,maxRows: 5}"
        placeholder="Enter something..."
      ></Input>
        </FormItem>-->
        <!-- <FormItem> -->
        <!-- <Button @click="handleReset('formValidate')" style="margin-left: 8px">Reset</Button> -->
        <!-- </FormItem> -->
      </Form>
    </div>
    <Button type="primary" @click="handleSubmit('formValidate')" class="ensureBtn">确认支付</Button>
  </div>
</template>
<script>
import tabBar from "../components/common/tabBar";
import timeLine from "../components/content/time-line";

export default {
  components: {
    timeLine,
    tabBar
  },
  data() {
    const validateMoney = (rule, value, callback) => {
      if (!value) {
        callback(new Error("请填写金额"));
        // console.log(value);
      }
      var reg = /^[0-9]+.?[0-9]*$/;
      // if (!reg.test(value)) {
      // console.log(praseInt(value));
      // }
      // 模拟异步验证效果
      setTimeout(() => {
        var reg = /^[0-9]+.?[0-9]*$/;
        if (!reg.test(value)) {
          callback(new Error("请填写数字"));
        } else {
          //  console.log('sdd');
          callback(console.log("问问"));
        }
      }, 1000);
    };

    const validateDeadline = (rule, value, callback) => {
      let now = Date.parse(new Date());
      let deadline = Date.parse(value);
      //  now =
      if (value === "") {
        callback(new Error("请选择下架时间"));
      }
      if (now > deadline) {
        callback(new Error("不能选择已过时间"));
        // console.log('日期不对')
      } else {
        callback();
        console.log("日期对");
      }
      // console.log(Date.parse(value));
      // console.log(value);
    };
    const validateCount = (rule, value, callback) => {
      // setTimeout(() => {
      if (!value) {
        callback(new Error("请填写"));
        console.log(value);
      } else {
        setTimeout(() => {
          var reg = /^[1-9]+[0-9]*]*$/;
          // if (value) {
          let xx = value.trim(); //去掉空格 记得保存数据时也去掉空格
          // }
          // console.log(value);
          // console.log(xx);
          if (!reg.test(xx)) {
            callback(new Error("请输入正确整数"));
          } else {
            callback(console.log("问问"));
          }
          // }, 1000);
          console.log("validateCount" + value);
        }, 1000);
      }
    };
    const validateRequiredTime = (rule, value, callback) => {
      let now = Date.parse(new Date());
      let deadline = Date.parse(value);
      if (!value) {
        callback(new Error("请填写"));
        // console.log(value);
      }
      var reg = /^[0-9]+.?[0-9]*$/;
      // if (!reg.test(value)) {
      // console.log(praseInt(value));
      // }
      // 模拟异步验证效果
      setTimeout(() => {
        var reg = /^[0-9]+.?[0-9]*$/;
        if (!reg.test(value)) {
          callback(new Error("请输入数字"));
        } else {
          //  console.log('sdd');
          callback(console.log("问问"));
        }
      }, 1000);
    };
    return {
      title: "上传任务",
      formValidate: {
        awardType: "",
         money: "",
        taskCount: "",
        requiredTime: "",
        deadline: ""
      },
      ruleValidate: {
        awardType: [
          {
            required: true,
            message: "奖励类型不能为空",
            trigger: "blur"
          }
        ],
        money: [
          {
            validator: validateMoney,
            required: true,
            // message: "请填写",
            trigger: "blur"
          }
          // { type: "email", message: "Incorrect email format", trigger: "blur" }
        ],
        taskCount: [
          {
            validator: validateCount,
            required: true,
            // message: "请填写",
            trigger: "blur"
          }
        ],
        requiredTime: [
          {
            validator: validateRequiredTime,
            required: true,
            type: "number",
            min: 1,
            // message: "请填写",
            trigger: "blur"
          }
        ],
        deadline: [
          {
            validator: validateDeadline,
            required: true,
            type: "date",
            // message: "请选择时间",
            trigger: "blur"
          }
        ]
        // time: [
        //   {
        //     required: true,
        //     type: "string",
        //     // message: "Please select time",
        //     trigger: "blur"
        //   }
        // ]
      }
    };
  },
  created(){
    this.$bus.$on('stepOneSuc',(data)=>{
      console.log('xxx')
      console.log(data)
    })
  },
  methods: {
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          this.$Message.success("Success!");
        } else {
          this.$Message.error("Fail!");
        }
      });
    },
    handleReset(name) {
      this.$refs[name].resetFields();
    }
  }
};
</script>
<style lang="less" scoped>
#step-three {
  width: 100%;
  height: 100%;
  position: relative;
  background: #ddd;
  overflow: scroll;
  //  border: 1px solid red;
  .content {
    width: 345px;
    margin: 0 auto;
    // border: 1px solid red;
    border-radius: 10px;
    background: #fff;
    margin-top: 12.5px;
    .ivu-form {
      // border: 1px yellow solid;
      padding: 10px 20px;
      margin-top: 5px;
      .ivu-form-item {
        position: relative;
        //  border: 1px solid red;
        // margin-bottom: 0;
        font-weight: bold;
        .delete-task {
          position: absolute;
          top: -34px;
          right: 0;
          span {
            vertical-align: middle;
            margin-left: 4px;
          }
          img {
            margin-top: 2px;
            width: 15px;
            height: 15px;
            vertical-align: middle;
          }
        }
        .ivu-date-picker {
          width: 300px;
        }
      }
      .money-count {
        margin-top: 10px;
        margin-bottom: 87.5px;
        .money,
        .charge,
        .pay {
          display: flex;
          justify-content: space-between;
          font-family: "PingFangTC";
          font-size: 12px;
          .right {
            color: #357edc;
          }
        }
      }
    }
  }
}
/deep/.ivu-input {
  border: none !important;
  border-bottom: 1px solid #efefef !important;
}
/deep/.ivu-select-selection {
  border: none !important;
  border-bottom: 1px solid #efefef !important;
}
.ensureBtn {
  margin-top: 28px;
  width: 300px;
  height: 42px;
  border-radius: 21px;
  background-image: linear-gradient(rgb(55, 140, 255), rgb(82, 112, 253));
  color: #fff;
  margin: 28px 35px;
}
</style>
