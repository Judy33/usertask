data() {
    return {
      title: "上传任务",
      index: 1,
      formDynamic: {
        items: [
          {
            value: "",
            index: 1,
            status: 1,
            taskImgUrl: ""
          }
        ]
      }
    };
  }