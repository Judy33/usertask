<template>
  <div id="step-two">
    <tab-bar :title="title" />
    <div class="content">
      <time-line :step="2" />
      <Form ref="formDynamic" :model="formDynamic" label-position="top" :rules="ruleCustom">
        <FormItem
          v-for="(item, index) in formDynamic.items"
          v-if="item.status"
          :key="index"
          :label="'任务步骤 ' + item.index"
          :prop="'items.' + index + '.value'"
        >
          <div @click="handleRemove(index)" class="delete-task" v-show="index>0">
            <img src="../assets/delete_red.png" alt />
            <span></span>
            <span>删除步骤{{index+1}}</span>
          </div>
          <Input v-model="item.value" type="textarea" :autosize="true" placeholder="输入任务详情" />
          <!-- <label for="taskImg" class="appIcon">
            <p>上传任务图片</p>
            <img src="../assets/upload.png" alt />
            <input
              type="file"
              id="taskImg"
              @change="uploadAppIcon"
              accept="image/gif, image/jpeg, image/jpg, image/png"
              style="display:none"
            />
          </label>-->
          <FormItem label="上传APP图标" class="form-item" prop="newAppIconUrl">
            <label for="taskImg" class="appIcon">
              <img v-show="item.newAppIconUrl?false:true" :src="item.appIconUrl" alt />
              <img v-show="item.newAppIconUrl?true:false" :src="item.newAppIconUrl" alt />
              <input
                type="file"
                id="taskImg"
                @change="uploadAppIcon"
                accept="image/gif, image/jpeg, image/jpg, image/png"
                style="display:none"
              />
            </label>
          </FormItem>
        </FormItem>
        <FormItem>
          <!-- <Row> -->
          <!-- <Col span="12"> -->
          <Button class="addStep" @click="handleAdd(currentIndex)" icon="md-add">添加步骤</Button>
          <!-- </Col>
          </Row>-->
        </FormItem>
      </Form>
    </div>
    <Button class="next-btn" @click="goStep3('formDynamic')">下一步</Button>
  </div>
</template>
<script>
import tabBar from "../components/common/tabBar";
import timeLine from "../components/content/time-line";

export default {
  components: {
    timeLine,
    tabBar
  },
  data() {
    const validateUrlIntro = (rule, value, callback) => {
      // if (value === "") {
      //   callback(new Error("请上传图片"));
      // }
      // console.log("图片url" + value);
      // setTimeout(() => {
      //   // if (!reg.test(value)) {
      //   //   callback(new Error("请输入正确姓名"));
      //   // } else {
      //   callback();
      //   // }
      // }, 1000);
    };
    const validateUrl = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请上传图片"));
      }
      console.log("图片url" + value);
      setTimeout(() => {
        // if (!reg.test(value)) {
        //   callback(new Error("请输入正确姓名"));
        // } else {
        callback();
        // }
      }, 1000);
    };
    return {
      title: "上传任务",
      index: 1,
      currentIndex: null,
      formDynamic: {
        items: [
          {
            value: "",
            index: 1,
            status: 1,
            newAppIconUrl: "",
            // productIntro: ""
            appIconUrl: require("../assets/upload.png")
          }
        ]
      },
      ruleCustom: {
        // productIntro: [
        //   {
        //     validator: validateUrlIntro,
        //     type: "string",
        //     trigger: "blur",
        //     min: 1,
        //     required: true,
        //     message: "请填写产品简介"
        //   }
        // ],
        newAppIconUrl: [
          {
            validator: validateUrl,
            type: "string",
            trigger: "change",
            // min: 2,
            required: true
            // message: "请上传图片!"
          }
        ]
      }
    };
  },
  methods: {
    getObjectUrl(file) {
      let url = null;
      if (window.createObjectURL != undefined) {
        // basic
        url = window.createObjectURL(file);
      } else if (window.webkitURL != undefined) {
        // webkit or chrome
        url = window.webkitURL.createObjectURL(file);
      } else if (window.URL != undefined) {
        // mozilla(firefox)
        url = window.URL.createObjectURL(file);
      }
      // this.appIconUrl = url;
      console.log("dsdsd" + this.index);
      // this.formDynamic.items[this.index];
      let items = this.formDynamic.items;
      let index = this.index - 1;
      console.log(index);
      items[index].appIconUrl = url;
      // this.appIconUrl = url;
      console.log(items[index]);
      console.log(items);
      items[index].newAppIconUrl = items[index].appIconUrl;
      console.log("这是图片的url" + items[index].newAppIconUrl);
      // console.log("items.index" + items.index);
    },

    //点击上传文件 获取文件
    uploadAppIcon(e) {
      this.file = e.target.files[0];
      if (!this.fristFile) {
        //没有上传过文件 就获取e.target
        this.fristFile = this.file;
        this.getObjectUrl(this.fristFile);
        this.ensureUpload = false;
        // console.log(this.formDynamic.items);
      } else {
        //没有取消选择图片
        if (e.target.files.length > 0) {
          this.getObjectUrl(e.target.files[0]);
        }
      }
      //获取图片地址
      // console.log("已经得到图片");
      // this.toAli(file)
    },

    //上传图片的加载层
    uploadImg() {
      this.$Spin.show({
        render: h => {
          return h("div", [
            h("Icon", {
              class: "demo-spin-icon-load",
              props: {
                type: "ios-loading",
                size: 18
              }
            }),
            h("div", "上传图片中")
          ]);
        }
      });
    },

    goStep3(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          // this.$router.push("./step3");
          this.$Message.success("Success!");
        } else {
          // this.$Message.error("Fail!");
        }
      });
    },

    handleSubmit(name) {
      // this.$refs[name].validate((valid) => {
      //     if (valid) {
      //         this.$Message.success('Success!');
      //     } else {
      //         this.$Message.error('Fail!');
      //     }
      // })
      this.$router.push("./step3");
    },
    // handleReset (name) {
    //     this.$refs[name].resetFields();
    // },
    handleAdd(cIndex) {
      if (this.formDynamic.items[cIndex].newAppIconUrl === "") {
        console.log("cccc");
        console.log(this.index);
        this.$Message.error("请先填写步骤" + cIndex);
      } else {
        this.index++;
        this.formDynamic.items.push({
          value: "",
          index: this.index,
          status: 1,
          newAppIconUrl: "",
          // productIntro: ""
          appIconUrl: require("../assets/upload.png")
        });
      }
    },
    //删除步骤
    handleRemove(index) {
      let items = this.formDynamic.items;
      console.log("cxxxxx");
     items[index].status = 0;
     items.splice(index,1)
      // this.index -= 1;
      console.log(items)
    },
    uploadImg(e) {
      console.log(e);
      //上传后获取文件
      var file = e.target.files[0];
      //获取图片地址
      this.getObjectUrl(file);
    }
  }
};
</script>
<style lang="less" scoped>
#step-two {
  width: 100%;
  height: 100%;
  position: relative;
  background: #ddd;
  overflow: scroll;
  .content {
    width: 345px;
    margin: 0 auto;
    // border: 1px solid red;
    border-radius: 10px;
    background: #fff;
    margin-top: 12.5px;
    .ivu-form {
      // border: 1px yellow solid;
      padding: 10px 20px;
      margin-top: 5px;
      .ivu-form-item {
        position: relative;
        //  border: 1px solid red;
        margin-bottom: 0;
        .delete-task {
          position: absolute;
          top: -50px;
          right: 0;
          span {
            vertical-align: middle;
            margin-left: 4px;
          }
          img {
            margin-top: 2px;
            width: 15px;
            height: 15px;
            vertical-align: middle;
          }
        }
      }
      .appIcon img {
        width: 80px;
        height: 80px;
        border-radius: 5px;
      }
    }
  }
}
img {
  width: 100%;
}
.appIcon {
  font-weight: bold;
  img {
    width: 80px;
    height: 80px;
    border-radius: 5px;
  }
}
.next-btn {
  margin-top: 28px;
  width: 300px;
  height: 42px;
  border-radius: 21px;
  background-image: linear-gradient(rgb(55, 140, 255), rgb(82, 112, 253));
  color: #fff;
  margin: 30px 35px;
}
/deep/.ivu-input {
  border: none !important;
  border-bottom: 1px solid #efefef !important;
}
/deep/.ivu-select-selection {
  border: none !important;
  border-bottom: 1px solid #efefef !important;
  width: 300px;
}
.addStep {
  width: 119px;
  height: 35px;
  border-radius: 17.5px;
  background-color: #4a78fe;
  color: #ffffff;
  font-size: 14;
  // line-height: 25px;
}
</style>