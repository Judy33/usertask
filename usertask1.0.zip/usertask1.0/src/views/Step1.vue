<template>
  <div class="step-one">
    <tab-bar :title="title" />
    <div class="content">
      <time-line :step="1" />
      <Form ref="formCustom" :model="formCustom" label-position="top" :rules="ruleCustom">
        <FormItem label="任务名称" class="form-item" prop="taskName">
          <Input v-model="formCustom.taskName" placeholder=" 请填写任务名称" />
          <!-- <input type="text" style="border:none; border-bottom: 1px solid red !important;" -->
        </FormItem>
        <FormItem label="产品名" class="form-item" prop="productName">
          <Input v-model="formCustom.productName" placeholder=" 请填写产品名称" />
        </FormItem>
        <FormItem label="产品简介" class="form-item" prop="productIntro">
          <Input type="textarea" :autosize="true" v-model="formCustom.productIntro" placeholder=" 请填写产品简介" />
        </FormItem>
        <FormItem label="上传APP图标" class="form-item" prop="newAppIconUrl">
          <label for="taskImg" class="appIcon">
            <img v-show="formCustom.newAppIconUrl?false:true" :src="appIconUrl" alt />
            <img v-show="formCustom.newAppIconUrl?true:false" :src="formCustom.newAppIconUrl" alt />
            <input
              type="file"
              id="taskImg"
              @change="uploadAppIcon"
              accept="image/gif, image/jpeg, image/jpg, image/png"
              style="display:none"
            />
          </label>
        </FormItem>
        <FormItem label="用户上传图片数" class="form-item" prop="imgCount">
          <Input v-model="formCustom.imgCount" placeholder="用户提交审核时需上传的图片的数量" />
        </FormItem>
        <FormItem label="用户是否需要上传文本" class="form-item" prop="select">
          <Select v-model="formCustom.select" placeholder="例如手机号/邮箱/微信号等相关任务证明">
            <Option value="need">需要</Option>
            <Option value="donotneed">不需要</Option>
          </Select>
        </FormItem>
      </Form>
    </div>
    <Button class="next-btn" @click="goStep2('formCustom')">下一步</Button>
  </div>
</template>
<script>
import timeLine from "../components/content/time-line";
import tabBar from "../components/common/tabBar";

export default {
  components: {
    timeLine,
    tabBar
  },
  data() {
    const validateUrl = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请上传图片"));
      }
      console.log("图片url"+value);
      setTimeout(() => {
        // if (!reg.test(value)) {
        //   callback(new Error("请输入正确姓名"));
        // } else {
        callback();
        // }
      }, 1000);
    };
    const validateCount = (rule, value, callback) => {
      if (!value) {
        callback(new Error("请输入数量!"));
        // console.log(value);
      }
      // if (!reg.test(value)) {
      // console.log(praseInt(value));
      // }
      // 模拟异步验证效果
      setTimeout(() => {
        var reg = /^[1-9]+[0-9]*]*$/;
        if (!reg.test(value)) {
          callback(new Error("请输入数字"));
        } else {
          //  console.log('sdd');
          callback(console.log("问问"));
        }
      }, 1000);
    };
    return {
      title: "上传任务",
      appIconUrl: require("../assets/upload.png"),
      formCustom: {
        taskName: "",
        productName: "",
        productIntro: "",
        imgCount: "",
        select: "",
        newAppIconUrl: ""
      },
      ruleCustom: {
        taskName: [
          {
            type: "string",
            trigger: "blur",
            // min: 2,
            required: true,
            message: "请填写任务名称"
          }
        ],
        productName: [
          {
            type: "string",
            trigger: "blur",
            // min: 2,
            required: true,
            message: "请填写产品名称"
          }
        ],
        productIntro: [
          {
            type: "string",
            trigger: "blur",
            // min: 2,
            required: true,
            message: "请填写产品简介"
          }
        ],

        newAppIconUrl: [
          {
            validator: validateUrl,
            type: "string",
            trigger: "change",
            // min: 2,
            required: true
            // message: "请上传图片!"
          }
        ],
        imgCount: [
          {
            validator: validateCount,
            // type: "number",
            trigger: "blur",
            // min: 2,
            required: true
            // message: "请输入!"
          }
        ],
        select: [
          {
            // type: "string",
            // trigger: "blur",
            // min: 2,
            required: true,
            message: "请选择!"
          }
        ]
      }
    };
  },
  methods: {
    getObjectUrl(file) {
      // this.
      let url = null;
      if (window.createObjectURL != undefined) {
        // basic
        url = window.createObjectURL(file);
      } else if (window.webkitURL != undefined) {
        // webkit or chrome
        url = window.webkitURL.createObjectURL(file);
      } else if (window.URL != undefined) {
        // mozilla(firefox)
        url = window.URL.createObjectURL(file);
      }
      this.appIconUrl = url;
      this.formCustom.newAppIconUrl = this.appIconUrl;
      console.log("这是图片的url" + this.appIconUrl);
    },

    //点击上传文件 获取文件
    uploadAppIcon(e) {
      this.file = e.target.files[0];
      if (!this.fristFile) {
        //没有上传过文件 就获取e.target
        this.fristFile = this.file;
        this.getObjectUrl(this.fristFile);
        this.ensureUpload = false;
      } else {
        //没有取消选择图片
        if (e.target.files.length > 0) {
          this.getObjectUrl(e.target.files[0]);
        }
      }
      //获取图片地址
      // console.log("已经得到图片");
      // this.toAli(file)
    },

    //上传图片的加载层
    uploadImg() {
      this.$Spin.show({
        render: h => {
          return h("div", [
            h("Icon", {
              class: "demo-spin-icon-load",
              props: {
                type: "ios-loading",
                size: 18
              }
            }),
            h("div", "上传图片中")
          ]);
        }
      });
    },

    goStep2(name) {
      console.log(this.formCustom)
      this.$refs[name].validate(valid => {
        console.log(this.formCustom)
        if (valid) {
          this.$router.push("./step2");
          this.$Message.success("Success!");
          // this.$bus.$emit('stepOneSuc',this.formCustom)
          this.$store.commit("getStepOneData",this.formCustom)
        } else {
          // this.$Message.error("Fail!");
        }
      });
    }

    // uploadAppIcon(e) {
    //   console.log(e);
    //   //上传后获取文件
    //   var file = e.target.files[0];
    //   //获取图片地址
    //   this.getObjectUrl(file);
    // },
    // getObjectUrl(file) {
    //   //获取图片地址
    //   let url = null;
    //   if (window.createObjectURL != undefined) {
    //     // basic
    //     url = window.createObjectURL(file);
    //   } else if (window.webkitURL != undefined) {
    //     // webkit or chrome
    //     url = window.webkitURL.createObjectURL(file);
    //   } else if (window.URL != undefined) {
    //     // mozilla(firefox)
    //     url = window.URL.createObjectURL(file);
    //   }
    //     this.formCustom.appIconUrl = url;
    //   //   console.log("这是图片的url" + this.formDynamic.items[0].taskImgUrl);
    // },
  }
};
</script>

<style lang="less" scoped>
.step-one {
  width: 100%;
  height: 100%;
  position: relative;
  background: #ddd;
  overflow: scroll;
  .content {
    width: 345px;
    margin: 0 auto;
    // border: 1px solid red;
    border-radius: 10px;
    background: #fff;
    margin-top: 12.5px;
    form {
      // border: 1px yellow solid;
      padding: 10px 0;
      margin-top: 5px;
      .form-item {
        font-size: 14px;
        // line-height: 5px;
        font-weight: bold;
        color: #2a2c31;
        //  border: 1px solid blue;
        width: 300px;
        margin-left: 21px;
      }
      .appIcon img {
        width: 80px;
        height: 80px;
        border-radius: 5px;
      }
    }
  }
  .ivu-btn {
    margin: 30px 35px;
    width: 300px;
    height: 35px;
    border-radius: 21px;
    background-image: linear-gradient(rgb(55, 140, 255), rgb(82, 112, 253));
    color: #fff;
    // margin: 0 auto;
  }
}
/deep/.ivu-input {
  border: none !important;
  border-bottom: 1px solid #efefef !important;
}
/deep/.ivu-select-selection {
  border: none !important;
  border-bottom: 1px solid #efefef !important;
  // width: 300px;
}
</style>
