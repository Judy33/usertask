<template>
  <div id="step-two">
    <tab-bar :title="title" />
    <div class="content">
      <time-line :step="2" />
      <Form ref="formDynamic" :model="formDynamic" label-position="top">
        <FormItem
          v-for="(item, index) in formDynamic.items"
          v-if="item.status"
          :key="index"
          :label="'任务步骤'+(index+1)"
        >
          <span class="necessaryMark">*</span>
          <div @click="handleRemove(index)" class="delete-task" v-show="index>0">
            <img src="../assets/delete_red.png" alt />
            <!-- <span></span> -->
            <span>删除步骤{{index+1}}</span>
          </div>
          <Input
            v-model="item.stepDescription"
            type="textarea"
            :autosize="true"
            placeholder="输入任务详情"
          />
          <!-- <label for="taskImg" class="appIcon">
            <p>上传任务图片</p>
            <img src="../assets/upload.png" alt />
            <input
              type="file"
              id="taskImg"
              @change="uploadAppIcon"
              accept="image/gif, image/jpeg, image/jpg, image/png"
              style="display:none"
            />
          </label>-->
          <FormItem label="上传APP图标" class="form-item">
            <span v-show="index == 0" :class="[index == 0? 'necessaryMark': '']">*</span>
            <label for="taskImg" class="appIcon">
              <img
                v-show="item.newAppIconUrl?false:true"
                :src="item.appIconUrl"
                alt
                @click="getIndex(index)"
              />
              <img
                v-show="item.newAppIconUrl?true:false"
                :src="item.newAppIconUrl"
                alt
                @click="getIndex(index)"
              />
              <input
                type="file"
                id="taskImg"
                @change="uploadAppIcon"
                accept="image/gif, image/jpeg, image/jpg, image/png"
                style="display:none"
              />
            </label>
          </FormItem>
        </FormItem>
        <FormItem>
          <!-- <Row> -->
          <!-- <Col span="12"> -->
          <Button class="addStep" @click="handleAdd" icon="md-add">添加步骤</Button>
          <!-- </Col>
          </Row>-->
        </FormItem>
      </Form>
    </div>
    <Button class="next-btn" @click="goStep3('formDynamic')">下一步</Button>
  </div>
</template>
<script>
import tabBar from "../components/common/tabBar";
import timeLine from "../components/content/time-line";

export default {
  components: {
    timeLine,
    tabBar
  },
  data() {
    const validateStepDesc = (rule, value, callback) => {
      // if (!value) {
      console.log(this.formDynamic.items[0].stepDescription);
      callback(new Error("请填写步骤1的任务详情!"));
      //  this.$Message.error("请填写步骤1的任务详情!");
      // }
      console.log("任务详情" + value);
      setTimeout(() => {
        // if (!reg.test(value)) {
        //   callback(new Error("请输入正确姓名"));
        // } else {
        callback();
        // }
      }, 1000);
    };
    const validateUrl = (rule, value, callback) => {
      if (!value) {
        callback(new Error("图片没传"));
      }
      console.log("图片url" + value);
      setTimeout(() => {
        // if (!reg.test(value)) {
        //   callback(new Error("请输入正确姓名"));
        // } else {
        callback();
        // }
      }, 1000);
    };
    return {
      title: "上传任务",
      index: 0,
      currentClickIndex: null,
      formDynamic: {
        items: [
          {
            // value: "www",
            stepDescription: "",
            index: 0,
            status: 1,
            newAppIconUrl: "",
            // productIntro: ""
            appIconUrl: require("../assets/upload.png")
          }
        ]
      }
      // ruleCustom: {
      //   stepDescription: [
      //     {
      //       // required: true,
      //       // validator: validateStepDesc,
      //       // trigger: "blur"
      //     }
      //   ],
      //   newAppIconUrl: [
      //     {
      //       validator: validateUrl,
      //       type: "string",
      //       trigger: "change",
      //       // min: 2,
      //       required: true,
      //       // message: "请上传图片!"
      //     }
      //   ]
      // }
    };
  },
  methods: {
    getObjectUrl(file) {
      let url = null;
      if (window.createObjectURL != undefined) {
        // basic
        url = window.createObjectURL(file);
      } else if (window.webkitURL != undefined) {
        // webkit or chrome
        url = window.webkitURL.createObjectURL(file);
      } else if (window.URL != undefined) {
        // mozilla(firefox)
        url = window.URL.createObjectURL(file);
      }
      let items = this.formDynamic.items;
      let index = this.currentClickIndex;
      console.log(index);
      items[index].appIconUrl = url;
      // this.appIconUrl = url;
      console.log(items[index]);
      console.log(items);
      items[index].newAppIconUrl = items[index].appIconUrl;
      console.log("这是图片的url" + items[index].newAppIconUrl);
    },

    //点击上传文件 获取文件
    uploadAppIcon(e) {
      this.file = e.target.files[0];
      if (!this.fristFile) {
        //没有上传过文件 就获取e.target
        this.fristFile = this.file;
        this.getObjectUrl(this.fristFile);
        this.ensureUpload = false;
        // console.log(this.formDynamic.items);
      } else {
        //没有取消选择图片
        if (e.target.files.length > 0) {
          this.getObjectUrl(e.target.files[0]);
        }
      }
      //获取图片地址
      // console.log("已经得到图片");
      // this.toAli(file)
    },
    //获取当前点击了那个图片
    getIndex(index) {
      console.log("我点了" + index);
      this.currentClickIndex = index;
    },
    //上传图片的加载层
    uploadImg() {
      this.$Spin.show({
        render: h => {
          return h("div", [
            h("Icon", {
              class: "demo-spin-icon-load",
              props: {
                type: "ios-loading",
                size: 18
              }
            }),
            h("div", "上传图片中")
          ]);
        }
      });
    },

    goStep3(name) {
      console.log(this.formDynamic);
      let items = this.formDynamic.items;
      for (let i = 0; i < items.length; i++) {
        // if (items[0].stepDescription == "" && items[0].newAppIconUrl == "") {
        //   this.$Message.error("请输入步骤一任务详情并上传图片");
        //   console.log('dsfs ')
        // } else
        // this.$Message.destroy();
        // if (items[i].stepDescription == "") {
        //   this.$Message.error("请输入任务详情");
        // } else if (items[0].newAppIconUrl == "") {
        //   this.$Message.error("请上传步骤一图片");
        //   // return
        // }else {
        //   console.log('w z执行了')    
        // }
        this.$Message.destroy();
        if (items[i].stepDescription == "" || items[0].newAppIconUrl == "") {
          if (items[i].stepDescription == "") {
            this.$Message.error("请输入任务详情");
          } else if (items[0].newAppIconUrl == "") {
            this.$Message.error("请上传步骤一图片");
            // return
          }
        } else {
          console.log("w z执行了");
        }
      }

      // this.$refs[name].validate(valid => {
      //   if (valid) {
      //     // this.$router.push("./step3");
      //     this.$Message.success("Success!");
      //   } else {
      //     // this.$Message.error("Fail!");
      //   }
      // });
    },

    handleSubmit(name) {
      // this.$refs[name].validate((valid) => {
      //     if (valid) {
      //         this.$Message.success('Success!');
      //     } else {
      //         this.$Message.error('Fail!');
      //     }
      // })
      this.$router.push("./step3");
    },
    // handleReset (name) {
    //     this.$refs[name].resetFields();
    // },
    handleAdd() {
      if (this.formDynamic.items.length >= 3) {
        this.$Message.error("步骤最多三步!");
        return;
      }
      this.index++;
      console.log(this.index);
      this.formDynamic.items.push({
        value: "",
        stepDescription: "",
        index: this.index,
        status: 1,
        newAppIconUrl: "",
        // productIntro: ""
        appIconUrl: require("../assets/upload.png")
      });
      // }
    },
    //删除步骤
    handleRemove(index) {
      let items = this.formDynamic.items;
      console.log("cxxxxx");
      items[index].status = 0;
      items.splice(index, 1);
      this.index = index;
      // this.index -= 1;
      console.log(items);
    },
    uploadImg(e) {
      console.log(e);
      //上传后获取文件
      var file = e.target.files[0];
      //获取图片地址
      this.getObjectUrl(file);
    }
  }
};
</script>
<style lang="less" scoped>
#step-two {
  width: 100%;
  height: 100%;
  position: relative;
  background: #ddd;
  overflow: scroll;
  .content {
    width: 345px;
    margin: 0 auto;
    // border: 1px solid red;
    border-radius: 10px;
    background: #fff;
    margin-top: 12.5px;
    .ivu-form {
      // border: 1px yellow solid;
      padding: 10px 20px;
      margin-top: 5px;
      .ivu-form-item {
        position: relative;
        //  border: 1px solid red;
        margin-bottom: 0;
        .necessaryMark {
          color: red;
          // margin-top: -20px;
          position: absolute;
          top: -30px;
          left: -10px;
          //  border: 1px solid red;
        }
        .delete-task {
          position: absolute;
          top: -50px;
          right: 0;
          span {
            vertical-align: middle;
            margin-left: 4px;
          }
          img {
            margin-top: 2px;
            width: 15px;
            height: 15px;
            vertical-align: middle;
          }
        }
      }
      .appIcon img {
        width: 80px;
        height: 80px;
        border-radius: 5px;
      }
    }
  }
}
img {
  width: 100%;
}
.appIcon {
  font-weight: bold;
  img {
    width: 80px;
    height: 80px;
    border-radius: 5px;
  }
}
.next-btn {
  margin-top: 28px;
  width: 300px;
  height: 42px;
  border-radius: 21px;
  background-image: linear-gradient(rgb(55, 140, 255), rgb(82, 112, 253));
  color: #fff;
  margin: 30px 35px;
}
/deep/.ivu-input {
  border: none !important;
  border-bottom: 1px solid #efefef !important;
}
/deep/.ivu-select-selection {
  border: none !important;
  border-bottom: 1px solid #efefef !important;
  width: 300px;
}
.addStep {
  width: 119px;
  height: 35px;
  border-radius: 17.5px;
  background-color: #4a78fe;
  color: #ffffff;
  font-size: 14;
  // line-height: 25px;
}
.ivu-form-item-error-tip {
  margin-bottom: 30px;
}
// .ivu-form-item-label:before {
//   content: "*";
//   display: block;
// }
</style>