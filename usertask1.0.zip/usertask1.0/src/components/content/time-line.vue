<template>
  <div class="prompt-box">
    <div class="prompt-box-text">
      <span :class="['prompt-box-text-number' , {noActive:step == 1 || step == 2 ||step == 3}]">1</span>
      <!-- :class="[{ active: isActive==index }, 'sort']" -->
       <span class="prompt-box-text-border"></span>
      <div class="prompt-box-text-text">步骤一</div>
    </div>
   
    <div class="prompt-box-text">
      <span :class="['prompt-box-text-number',{noActive:step == 2 ||step == 3}]">2</span>
      <span class="prompt-box-text-border"></span>
      <div class="prompt-box-text-text">步骤二</div>
    </div>
    <div class="prompt-box-text">
      <span :class="['prompt-box-text-number',{noActive:step == 3}]">3</span>
      <div class="prompt-box-text-text">步骤三</div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    step: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {};
  }
};
</script>

<style>
.prompt-box {
  display: flex;
  /* margin-left: 45.5px; */
  width: 300px;
  /* border: 1px solid red; */
  margin: 0 auto;
  /* text-align: center; */
  justify-content: space-between;
  /* flex-wrap: nowrap; */
}
.prompt-box-text {
  margin-top: 24px;
  position: relative;
  /* border: 1px solid red; */
  text-align: center;
}
.prompt-box-text-text {
  /* margin-left: -10px; */
  font-weight: bold;
  /* border: 1px solid #3f94fe; */
}
.prompt-box-text-number {
  /* -webkit-border-radius: 200px;
  -moz-border-radius: 200px; */
  border-radius: 200px;
  border: 1px solid #dddddd;
  text-align: center;
  color: #fff;
  display: inline-block;
  width: 24px;
  height: 24px;
  line-height: 24px;
  /* -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box; */
  box-sizing: border-box;
  font-size: 12px;
  /* margin-right: 0.833rem; */
  /* letter-spacing: 0; */
  /* vertical-align: top; */
  background-color: #dddddd;
  position: relative;
  z-index: 1;
  margin-bottom: 5px;
}
.prompt-box-text-border {
  width: 130px;
  border-top: 1px dotted #dddddd;
  display: block;
  /* content: ''; */
  /* line-height: 24px; */
  /* /* margin: -12px; */
  position: absolute;
  left: 10px;
  top: 12px;
  /* left: 10px; */
}
.noActive {
  border: 1px solid #3f94fe;
  background-color: #3f94fe;
}
</style>