<template>
  <div id="nextBtn">
    <button>下一步</button>
  </div>
</template>

<script>
export default {};
</script>

<style>
#nextBtn button {
  width: 300px;
  height: 42px;
  border-radius: 21px;
  background-image: linear-gradient(rgb(55,140,255), rgb(82,112,253));
  color: #fff;
  margin: 0 auto;
}
</style>