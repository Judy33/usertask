<template>
  <div id="title">
    <!-- <slot> -->
    <img src="../../assets/arrow.png" alt @click="goBack" />
    <span>{{title}}</span>
  </div>
</template>

<script>
export default {
  props: ["title"],
  data() {
    return {};
  },
  methods: {
    goBack() {
        this.$router.back()
    }
  }
};
</script>

<style lang="less">
#title {
  width: 100%;
  height: 70px;
  background: #fff;
  border-bottom: 1px solid #ddd;
  position: relative;
  text-align: center;
  span {
    font-size: 16px;
    font-weight: bold;
    line-height: 70px;
  }
  img {
    width: 20px;
    position: absolute;
    margin-left: 10px;
    top: 50%;
    left: 0;
    transform: translate(0, -50%);
  }
}
</style>