import Vue from 'vue'
import VueRouter from 'vue-router'
import Step1 from '../views/Step1.vue'

Vue.use(VueRouter)

  const routes = [
  {
    path: '/',
    redirect: '/step1',
    // component: Step1
  },
  {
    path: '/step1',
    name: 'Step1',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/Step1.vue')
  },
  {
    path: '/step2',
    name: 'Step2',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/Step2.vue')
  },
  {
    path: '/step3',
    name: 'Step3',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/Step3.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
